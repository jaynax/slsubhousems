@extends('layouts.admin.index')

@section('content')
<div class="container">
    <h2>Boarding Houses</h2>
    @foreach($boardingHouses as $house)
        <h3>{{ $house->name }} (₱{{ $house->rent }})</h3>
        <p>Location: {{ $house->location }}</p>
        <p>Tenants: {{ $house->tenants->count() }}</p>
        <table class="table">
            <tr>
                <th>Name</th>
                <th>Contact</th>
                <th>Room Number</th>
                <th>Payment Status</th>
            </tr>
            @foreach($house->tenants as $tenant)
                <tr>
                    <td>{{ $tenant->user->name }}</td>
                    <td>{{ $tenant->user->contact }}</td>
                    <td>{{ $tenant->room_number }}</td>
                    <td>
                        @if($tenant->payment)
                            {{ $tenant->payment->status == 'paid' ? 'Paid' : 'Unpaid' }}
                        @else
                            Unpaid
                        @endif
                    </td>
                </tr>
            @endforeach
        </table>
    @endforeach
</div>
@endsection
